package Otomate;


public class TestAlicia {

	public static void main(String[] args) {
		Jeu.initPartie();

	}

}
