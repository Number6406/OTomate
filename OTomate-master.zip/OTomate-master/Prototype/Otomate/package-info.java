/**
 * 
 */
/**
 * @author Stractus
 *
 */
package Otomate;